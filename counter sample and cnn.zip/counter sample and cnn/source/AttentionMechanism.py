#!/usr/bin/env python 
# -*- coding:utf-8 -*-
from stanfordcorenlp import StanfordCoreNLP

import numpy as np
import math
import tensorflow as tf

from nltk.tree import ParentedTree
nlp = StanfordCoreNLP('D:\\stanfordNLP', lang='en')
w2v_dir = 'D:\dataset\glove.6B.50d.txt'
dictionary = {}
embeddings = []

with open(w2v_dir,'r',encoding="UTF8") as f:
    words = [x.rstrip().split(' ')[0] for x in f.readlines()]
    words = words[:10000]
    dictionary  = {word:(index) for index, word in enumerate(words)}
    #print(dictionary)
    del words
with open(w2v_dir,'r',encoding="UTF8") as f:
    vectors = [[float(y) for y in x.rstrip().split(' ')[1:]] for x in f.readlines()]
    vectors = vectors[:10000]
    embeddings = embeddings + vectors
    #print(embeddings)
    del vectors

class AttentionModel:

    def cos(self,sen1_vector,sen2_vector):
        cos_distance=np.dot(sen1_vector, sen2_vector) / (np.linalg.norm(sen1_vector) * np.linalg.norm(sen2_vector))
        return cos_distance
    def pos(self,i,j):
        pos_distance=math.exp(-abs(i-j))
        return pos_distance
    def softmax(self,vector):
        every_vector=[math.exp(x) for x in vector]
        sum = np.sum(every_vector, 0)
        result = [math.exp(y)/sum for y in vector]
        return result
    def get_AttentionVector(self,sentence1, sentence2):
        zero = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        embed = embeddings
        dict = dictionary
        english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '``', '\'\'']
        participle_Sen1 = nlp.word_tokenize(sentence1.lower())
        participle_Sen2 = nlp.word_tokenize(sentence2.lower())
        common_element1 = [x for x in participle_Sen1 if x in english_punctuations]
        Result_Sentence1 = [y for y in participle_Sen1 if y not in common_element1]
        common_element2 = [x for x in participle_Sen2 if x in english_punctuations]
        Result_Sentence2 = [y for y in participle_Sen2 if y not in common_element2]
        index_Sen1=[dict.get(word) for word in Result_Sentence1]
        wordEmbedding_Sen1=[embed[y] for y in index_Sen1 if y !=None]
        index_Sen2 = [dict.get(word) for word in Result_Sentence2]
        wordEmbedding_Sen2 = [embed[y] for y in index_Sen2 if y!=None]
        Attention_Matrix = np.ones((len(wordEmbedding_Sen1),len(wordEmbedding_Sen2)))
        i=0
        j=0
        for sen1_vector in wordEmbedding_Sen1:
            for sen2_vector in wordEmbedding_Sen2:
                if Result_Sentence1[i] == Result_Sentence2[j]:#判断单词是否相同，如果相同则计算余弦距离和位置距离
                    cos_distance=AttentionModel().cos(sen1_vector,sen2_vector)
                    pos_distance=AttentionModel().pos(i, j)
                    Attention_Matrix[i][j] = cos_distance+pos_distance
                    j=j+1
                else:
                    Attention_Matrix[i][j] = AttentionModel().cos(sen1_vector, sen2_vector)
                    j=j+1
            i=i+1
            j=0
        row_vector=np.sum(Attention_Matrix, 1)
        col_vector=np.sum(Attention_Matrix, 0)
        softmax_rowvec=AttentionModel().softmax(row_vector)
        softmax_colvec=AttentionModel().softmax(col_vector)
        Attention_Sen1_Matrix = []
        Attention_Sen2_Matrix = []
        for i in range(len(softmax_rowvec)):
            a = [j*softmax_rowvec[i] for j in wordEmbedding_Sen1[i]]
            Attention_Sen1_Matrix.append(a)
        for i in range(len(softmax_colvec)):
            a = [j*softmax_colvec[i] for j in wordEmbedding_Sen2[i]]
            Attention_Sen2_Matrix.append(a)
        for i in range(40-len(Attention_Sen1_Matrix)):
            Attention_Sen1_Matrix.append(zero)
        for j in range(40-len(Attention_Sen2_Matrix)):
            Attention_Sen2_Matrix.append(zero)
        return Attention_Sen1_Matrix, Attention_Sen2_Matrix
    def get_AttentionVector2(self,wordEmbedding_Sen1, wordEmbedding_Sen2):
        zero = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        Attention_Matrix = np.ones((len(wordEmbedding_Sen1),len(wordEmbedding_Sen2)))
        i=0
        j=0
        for sen1_vector in wordEmbedding_Sen1:
            for sen2_vector in wordEmbedding_Sen2:
                if wordEmbedding_Sen1[i] == wordEmbedding_Sen2[j]:
                    cos_distance=AttentionModel().cos(sen1_vector,sen2_vector)
                    pos_distance=AttentionModel().pos(i, j)
                    Attention_Matrix[i][j] = cos_distance+pos_distance
                    j=j+1
                else:
                    Attention_Matrix[i][j] = AttentionModel().cos(sen1_vector, sen2_vector)
                    j=j+1
            i=i+1
            j=0
        row_vector=np.sum(Attention_Matrix, 1)
        col_vector=np.sum(Attention_Matrix, 0)
        softmax_rowvec=AttentionModel().softmax(row_vector)
        softmax_colvec=AttentionModel().softmax(col_vector)
        Attention_Sen1_Matrix = []
        Attention_Sen2_Matrix = []
        for i in range(len(softmax_rowvec)):
            a = [j*softmax_rowvec[i] for j in wordEmbedding_Sen1[i]]
            Attention_Sen1_Matrix.append(a)
        for i in range(len(softmax_colvec)):
            a = [j*softmax_colvec[i] for j in wordEmbedding_Sen2[i]]
            Attention_Sen2_Matrix.append(a)
        for i in range(40-len(Attention_Sen1_Matrix)):
            Attention_Sen1_Matrix.append(zero)
        for j in range(40-len(Attention_Sen2_Matrix)):
            Attention_Sen2_Matrix.append(zero)
        return Attention_Sen1_Matrix, Attention_Sen2_Matrix

if __name__ == '__main__':
    sentence1="helmand province is the world's largest opium-producing region."
    sentence2="helmand province is the world's largest producer of opium."
    a, b = AttentionModel().get_AttentionVector(sentence1, sentence2)

    c=tf.reshape(a, [40, 50])
    sess = tf.Session()




