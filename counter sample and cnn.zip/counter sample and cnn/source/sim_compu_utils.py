# -*- coding: utf-8 -*-

import tensorflow as tf

def compute_l1_distance(x, y):
    with tf.name_scope('L1_distance'):
        d = tf.exp(-tf.reduce_sum(tf.abs(tf.subtract(x, y)), 1))
        return d

def compute_euclidean_distance(x, y):
    with tf.name_scope('euclidean_distance'):
        d = tf.sqrt(tf.reduce_sum(tf.square(tf.subtract(x, y)), 1))
        return d

def compute_cosine_distance(x, y):
    with tf.name_scope('cosine_distance'):
        up = tf.reduce_sum(tf.multiply(x, y),1)
        low1 = tf.sqrt(tf.reduce_sum(tf.square(x),1))
        low2 = tf.sqrt(tf.reduce_sum(tf.square(y),1))
        d = up / (low1*low2)
        return d

# def comU1(x, y):
#     result = [compute_cosine_dinstance(x, y), compute_euclidean_distance(x, y), compute_l1_distance(x, y)]
#     return tf.stack(result, axis=1)
#
# def comU2(x, y):
#     result = [compute_cosine_dinstance(x, y), compute_euclidean_distance(x, y)]
#     return tf.stack(result, axis=1)

def comU1(x, y):
    result = [compute_cosine_distance(x, y), compute_l1_distance(x, y)]
    # result = [compute_euclidean_distance(x, y), compute_euclidean_distance(x, y), compute_euclidean_distance(x, y)]
    return tf.stack(result, axis=1)


def comU2(x, y):
    # result = [compute_cosine_distance(x, y), compute_euclidean_distance(x, y)]
    # return tf.stack(result, axis=1)
    return tf.expand_dims(compute_cosine_distance(x, y), -1)
