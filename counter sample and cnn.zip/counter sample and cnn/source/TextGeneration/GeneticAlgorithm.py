#!/usr/bin/env python 
# -*- coding:utf-8 -*-
from AttentionMechanism import AttentionModel
import readfile
import random
import sim_compu_utils as scu
from stanfordcorenlp import StanfordCoreNLP
from PyDictionary import PyDictionary
import tensorflow as tf
from nltk.corpus import wordnet as wn

zero = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
threshod1 = 0.02
dictionary = PyDictionary()
nlp = StanfordCoreNLP('D:\\stanfordNLP', lang='en')
embed = readfile.embeddings
dict = readfile.dictionary
def getFenci(sentence1, sentence2):
    english_punctuations = [',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*', '@', '#', '$', '%', '``',
                            '\'\'']
    participle_Sen1 = nlp.word_tokenize(sentence1.lower())
    participle_Sen2 = nlp.word_tokenize(sentence2.lower())
    common_element1 = [x for x in participle_Sen1 if x in english_punctuations]

    Result_Sentence1 = [y for y in participle_Sen1 if y not in common_element1]

    common_element2 = [x for x in participle_Sen2 if x in english_punctuations]
    Result_Sentence2 = [y for y in participle_Sen2 if y not in common_element2]
    return Result_Sentence1, Result_Sentence2

def getAdvertextAndRatio(Result_Sentence1, Result_Sentence2):
    random1 = random.randint(0, len(Result_Sentence1)-1)

    #rowCollection_syno = dictionary.synonym("good")
    #print("rowCollection_syno", rowCollection_syno)
    rowCollection_syno = synList(Result_Sentence1[random1])
    rowCollection_syno.append("is")

    while len(rowCollection_syno) == 0:
        random1 = random.randint(0, len(Result_Sentence1) - 1)
        rowCollection_syno = synList(Result_Sentence1[random1])

    result_syn1_emd = []
    filter_syn1 = []
    index_Sen1 = [dict.get(word) for word in rowCollection_syno if rowCollection_syno != None]
    wordEmbedding_Sen1 = [embed[y] for y in index_Sen1 if y != None]

    index = dict.get(Result_Sentence1[random1])
    if index != None:
        wordvector = embed[index]
    else:
        wordvector = [1.0 for i in range(50)]
    for j, i in enumerate(wordEmbedding_Sen1):
        i = tf.reshape(i, [-1, 50])
        wordvector = tf.reshape(i, [-1, 50])
        sim = scu.compute_cosine_distance(wordvector, i)
        sess = tf.Session()
        sess.run(tf.global_variables_initializer())
        sim = sim.eval(session=sess)

        if sim > threshod1:
            result_syn1_emd.append(wordEmbedding_Sen1[j])
            filter_syn1.append(rowCollection_syno[j])
    random2 = random.randint(0, len(Result_Sentence2)-2)

    rowCollection_syno1 = synList(Result_Sentence2[random2])
    rowCollection_syno1.append('is')
    while len(rowCollection_syno1) == 0:
        random2 = random.randint(0, len(Result_Sentence2) - 1)
        rowCollection_syno1 = synList(Result_Sentence2[random2])

    result_syn2_emd = []
    filter_syn2 = []
    index_Sen2 = [dict.get(word) for word in rowCollection_syno1 if rowCollection_syno1 != None]
    wordEmbedding_Sen2 = [embed[y] for y in index_Sen2 if y != None]
    index = dict.get(Result_Sentence2[random2])
    if index != None:
        wordvector = embed[index]
    else:
        wordvector = [1.0 for i in range(50)]
    for j, i in enumerate(wordEmbedding_Sen2):
        i = tf.reshape(i, [-1, 50])
        wordvector = tf.reshape(i, [-1, 50])
        sim = scu.compute_cosine_distance(wordvector, i)
        sess = tf.Session()
        sess.run(tf.global_variables_initializer())
        sim = sim.eval(session=sess)
        if sim > threshod1:
            result_syn2_emd.append(wordEmbedding_Sen2[j])
            filter_syn2.append(rowCollection_syno1[j])
    return result_syn1_emd, result_syn2_emd, random1, random2, filter_syn1, filter_syn2
def fitness(sentence1, sentence2, std_score):
    alpha = 0.21
    Attention_Sen1_Matrix_input = []
    Attention_Sen2_Matrix_input = []
    Result_Sentence1, Result_Sentence2 = getFenci(sentence1, sentence2)
    result_syn1_emd, result_syn2_emd, random1, random2, filter_syn1, filter_syn2 = getAdvertextAndRatio(Result_Sentence1, Result_Sentence2)
    index_Sen1 = [dict.get(word) for word in Result_Sentence1 if Result_Sentence1 != None]
    wordEmbedding_Sen1 = []
    for y in index_Sen1:
        if y != None:
            wordEmbedding_Sen1.append(embed[y])
        else:
            wordEmbedding_Sen1.append(zero)

    index_Sen2 = [dict.get(word) for word in Result_Sentence2 if Result_Sentence2 != None]
    wordEmbedding_Sen2 = []
    for y in index_Sen2:
        if y != None:
            wordEmbedding_Sen2.append(embed[y])
        else:
            wordEmbedding_Sen2.append(zero)

    iteratorCon = len(result_syn2_emd) if len(result_syn1_emd) > len(result_syn2_emd) else len(result_syn1_emd)

    for i in range(iteratorCon):
        wordEmbedding_Sen1[random1] = result_syn1_emd[i]
        wordEmbedding_Sen2[random2] = result_syn1_emd[i]
        Attention_Sen1_Matrix, Attention_Sen2_Matrix = AttentionModel().get_AttentionVector2(wordEmbedding_Sen1, wordEmbedding_Sen2)

        Attention_Sen1_Matrix_input.append(Attention_Sen1_Matrix)
        Attention_Sen2_Matrix_input.append(Attention_Sen2_Matrix)
        #print("Attention_Sen1_Matrix_input = {0}, type = {1}".format(Attention_Sen1_Matrix_input, Attention_Sen2_Matrix_input))

    with tf.Session() as sess:
        saver = tf.train.import_meta_graph('../ckpt/ncnn.ckpt.meta')
        saver.restore(sess, tf.train.latest_checkpoint('../ckpt'))
        graph = tf.get_default_graph()

        sentence1 = graph.get_tensor_by_name("sentence1:0")
        sentence2 = graph.get_tensor_by_name("sentence2:0")
        output = graph.get_tensor_by_name("output:0")
        pred = sess.run(output, feed_dict={sentence1: Attention_Sen1_Matrix_input, sentence2: Attention_Sen2_Matrix_input})

        fitlist = fitenessCompute(pred, std_score, iteratorCon, alpha)
        fitlist = sess.run(fitlist)
        finalIndex = fitlist.index(max(fitlist))
        Result_Sentence1[random1] = filter_syn1[finalIndex]
        Result_Sentence2[random2] = filter_syn2[finalIndex]
        return Result_Sentence1, Result_Sentence2

def fitenessCompute(pred, std_score, iteratorCon, alpha):
    fitlist = []
    for i in pred:
        fit = alpha/tf.abs(i - std_score) + alpha/iteratorCon
        fitlist.append(fit)
    return fitlist

def synList(word):
    word_synset = set()
    synsets = wn.synsets(word)
    for synset in synsets:
        words = synset.lemma_names()
        for word in words:
            word = word.replace('_', ' ')
            word_synset.add(word)
    return list(word_synset)

def writeInFile(adv_dir, adv_sentence1_list, adv_sentence2_list, z):
    adv_sentence1 = ' '.join(adv_sentence1_list)
    adv_sentence2 = ' '.join(adv_sentence2_list)
    adv_sentencePari = z +"\t"+ "palceholder"+"\t"+"palceholder"+ "\t" + adv_sentence1 + "\t" +adv_sentence2

    with open(adv_dir, 'a', encoding="UTF8") as f:
        f.write(adv_sentencePari+'\n')
        f.close()

def readFile(filename):
    sentencex = []
    sentencey = []
    z = []
    f = open(filename, 'r', encoding="UTF8")
    dataset = f.readlines()
    f.close()
    dataset = dataset[1:]
    for i in dataset[500:540]:
        data = i.strip().split('\t')
        sentencex.append(data[3])
        sentencey.append(data[4])
        z.append(data[0])
    return sentencex, sentencey, z

if __name__ == '__main__':
    adv_dir = "F:\\advtext.txt"
    dataset_dir = "../dataset/msrp/counter_msr_paraphrase_test.txt"
    sentencex, sentencey, z = readFile(dataset_dir)

    for i in range(len(z)):
        adv_sentence1, adv_sentence2 = fitness(sentencex[i], sentencey[i], float(int(z[i])))
        writeInFile(adv_dir, adv_sentence1, adv_sentence2, z[i])



