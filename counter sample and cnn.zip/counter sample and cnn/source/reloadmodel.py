#!/usr/bin/env python 
# -*- coding:utf-8 -*-
import tensorflow as tf
from readfile import ReadDataset
sentence_dir = "./dataset/msrp/counter_msr_paraphrase_test.txt"
train_dataset = ReadDataset(sentence_dir)
x, y, z = train_dataset.next_batch(1985)
def cmp(var1, var2):
    tmp = 0
    if var1 >= 0.5:
        tmp = 1.
    else:
        tmp = 0.
    if (tmp == var2):
        return 1.
    else:
        return 0.
with tf.Session() as sess:
    saver = tf.train.import_meta_graph('./ckpt/ncnn.ckpt.meta')
    saver.restore(sess, tf.train.latest_checkpoint('./ckpt'))
    graph = tf.get_default_graph()
    sentence1  = graph.get_tensor_by_name("sentence1:0")
    sentence2 = graph.get_tensor_by_name("sentence2:0")
    output = graph.get_tensor_by_name("output:0")
    pred = sess.run(output, feed_dict= {sentence1:x, sentence2:y})
    result = list(map(cmp, pred, z))
    accuary = sum(result) / len(result)
    print("accuracy", accuary)




